$(function() {
    $('#Consepto').on('change', cambio);
});
function cambio() {
  var id_conc = $(this).val();
  //ajax
  if (! id_conc )
      $('#SubConsepto').html('<option value="">Seleccione un SubConcepto</option>');
  $.get('/api/IngEgre/'+id_conc+'/SubConsepto', function(data){
      var html_select = '<option value="">Seleccione un SubConcepto</option>';
      for (var i = 0; i < data.length; i++) {
        html_select += '<option value="'+data[i].name+'">'+data[i].name+'</option>';
      }
      $('#SubConsepto').html(html_select);
  });
}

$(function() {
    $('#Consepto2').on('change', cambio2);
});
function cambio2() {
  var id_conc = $(this).val();
  //ajax
  if (! id_conc )
      $('#SubConsepto2').html('<option value="">Seleccione un SubConcepto</option>');
  $.get('/api/IngEgre/'+id_conc+'/SubConsepto2', function(data){
      var html_select = '<option value="">Seleccione un SubConcepto</option>';
      for (var i = 0; i < data.length; i++) {
        html_select += '<option value="'+data[i].name+'">'+data[i].name+'</option>';
      }
      $('#SubConsepto2').html(html_select);
  });
}






//admin


$(function() {
    $('#ConseptoA').on('change', cambioA);
});
function cambioA() {
  var id_conc = $(this).val();
  //ajax
  if (! id_conc )
      $('#SubConsepto').html('<option value="">Seleccione un SubConcepto</option>');
  $.get('/api/IngEgre/'+id_conc+'/SubConseptoA', function(data){
      var html_select = '<option value="">Seleccione un SubConcepto</option>';
      for (var i = 0; i < data.length; i++) {
        html_select += '<option value="'+data[i].name+'">'+data[i].name+'</option>';
      }
      $('#SubConsepto').html(html_select);
  });
}

$(function() {
    $('#ConseptoA2').on('change', cambioA2);
});
function cambioA2() {
  var id_conc = $(this).val();
  //ajax
  if (! id_conc )
      $('#SubConsepto2').html('<option value="">Seleccione un SubConcepto</option>');
  $.get('/api/IngEgre/'+id_conc+'/SubConseptoA2', function(data){
      var html_select = '<option value="">Seleccione un SubConcepto</option>';
      for (var i = 0; i < data.length; i++) {
        html_select += '<option value="'+data[i].name+'">'+data[i].name+'</option>';
      }
      $('#SubConsepto2').html(html_select);
  });
}
